﻿


default contratou_roxy = False

default roxy_afeicao = 0


define roxy_gifted_today = False
define roxy_talked_today = False
define roxy_interacted_today = False


label roxy_intro:
    show rudeus normal at left, slide_fade
    show roxy normal at right, slide_fade
    roxy "Да?"
    jump roxy_menu




label roxy_pre_menu:
    scene bg taverna with fade

    "Ты входишь в таверну. В воздухе витает тёплый запах эля и жареного мяса."

    rudeus "(Хм? Кто это там сидит в одиночестве в углу?)"

    show roxy normal at center, slide_fade
    with dissolve

    rudeus "(Ого. Симпатичная. Даже очень.)"

    rudeus "(Интересно, что она здесь делает совсем одна?)"

    show roxy:
        ease 0.5 xalign 0.8

    show rudeus normal at my_left, slide_fade

    rudeus "Привет. Не против, если я немного посижу с тобой?"

    roxy "Ой! Эм... к-конечно, садись..."

    rudeus "Итак, что такая девушка, как ты, делает одна в таком месте?"

    roxy "Я-я не просто «девушка»... Вообще-то я обучаю магии."

    rudeus "(Наставница по магии? Да ещё и симпатичная... Хех, повезло мне.)"

    rudeus "Наставница по магии, значит? Впечатляет."

    roxy "Я-знаю, что могу не выглядеть как наставница, но в магии я действительно разбираюсь."

    rudeus "Я ни капли в этом не сомневаюсь. Так... сколько ты возьмёшь за уроки?"

    roxy "Один урок стоит 25 золотых монет."

    rudeus "Вполне справедливо. Честно говоря, мне не помешал бы такой наставник."

    menu:
        "Hire her as your tutor":
            rudeus "Отлично, ты принята. Добро пожаловать в команду, учитель."

            roxy "П-Правда?! Ты серьёзно?"

            "Лицо Рокси озаряется, и она широко улыбается."

            roxy "Огромное спасибо! Обещаю, что стану отличным наставником!"

            $ contratou_roxy = True
            $ roxy_evento = 1
            $ renpy.notify("Ты нанял Рокси в качестве наставницы по магии!")
            jump locais


image roxy normal:
    "images/pers/roxy/roxy normal.png"
    zoom 0.5

label roxy_menu:
    menu:


        "💬Поговорить" if not roxy_talked_today:

            $ chat_reward = get_chat_reward(roxy_afeicao)
            rudeus "Ну что, Рокси… как проходит твой день?"
            roxy "О… Всё хорошо… Спасибо, что спросил!"
            $ roxy_afeicao += chat_reward
            $ roxy_talked_today = True
            $ renpy.notify("Твоя привязанность к Рокси повысилась на +{}!".format(chat_reward))
            jump roxy_menu

        "🎁Подарить подарок" if not roxy_gifted_today:
            $ available_gifts = []
            if simple_flower_count > 0:
                $ available_gifts.append(("simple_flower", "Простой цветок", simple_flower_count, 10))
            if chocolate_box_count > 0:
                $ available_gifts.append(("chocolate_box", "Коробка шоколадных конфет", chocolate_box_count, 25))
            if luxury_jewelry_count > 0:
                $ available_gifts.append(("luxury_jewelry", "Бриллиантовая серьга", luxury_jewelry_count, 50))



            $ chosen_gift = renpy.call_screen("gift_selection_screen", "roxy", "roxy", available_gifts)

            if chosen_gift == "simple_flower":
                $ simple_flower_count -= 1
                rudeus "Рокси, я принёс тебе цветок!"
                roxy "Ой! Цветок для меня? Большое спасибо."
                $ roxy_afeicao += 10
                $ roxy_gifted_today = True
                $ renpy.notify("Рокси понравился подарок! +10 к привязанности")

            elif chosen_gift == "chocolate_box":
                $ chocolate_box_count -= 1
                rudeus "Рокси, я принёс тебе изысканные шоколадные конфеты!"
                roxy "Ух ты! Выглядят очень аппетитно!"
                $ roxy_afeicao += 25
                $ roxy_gifted_today = True
                $ renpy.notify("Рокси понравился подарок! +25 к привязанности")

            elif chosen_gift == "luxury_jewelry":
                $ luxury_jewelry_count -= 1
                rudeus "Рокси... Я хочу, чтобы это было у тебя."
                roxy "Это... драгоценность?! Не стоило так тратиться!"
                roxy "Она такая красивая... Я буду хранить её всю жизнь!"
                $ roxy_afeicao += 50
                $ roxy_gifted_today = True
                $ renpy.notify("Рокси понравился подарок! +50 к привязанности")

            elif chosen_gift == "premium_necklace":
                $ premium_necklace_count -= 1
                rudeus "Рокси... Это ожерелье показывает, как много ты для меня значишь."
                roxy "Рудеус... Оно просто великолепно! Я никогда не видела ничего подобного!"
                roxy "Огромное спасибо! Для меня это очень много значит!"
                $ roxy_afeicao += 125
                $ roxy_gifted_today = True
                $ renpy.notify("Рокси в полном восторге от подарка! +125 к привязанности")
            else:

                pass

            jump roxy_menu


        "😏Взаимодействовать" if not roxy_interacted_today:
            label roxy_interact_menu:

                menu:
                    "Попросить показать трусики (30)":

                        if roxy_afeicao < 30:
                            "Чтобы открыть этот вариант, нужно не менее 30 очков привязанности."
                            jump roxy_interact_menu
                        else:
                            rudeus "Рокси… покажи мне свои трусики."
                            roxy "М-моё... бельё? Рудеус, зачем ты просишь о таком?"
                            rudeus "Ну же… уверен, на тебе очень соблазнительное бельё."
                            rudeus "Мне бы хотелось, чтобы ты показала их мне…"
                            roxy "Л-ладно… но только один раз!"
                            show vid_roxy_showing with fade
                            rudeus "Вот это да, Рокси… тебе невероятно идут эти трусики…"
                            roxy "Т-тебе понравилось?"
                            rudeus "Ещё бы… И пахнут они чудесно…"
                            roxy "Т-тебе не следует говорить такое, Рудеус…"
                            rudeus "Ахх… Учитель… ты такая чертовски привлекательная…"
                            rudeus "Не могу отвести взгляд…"
                            roxy "М-м… Ну и извращенец же ты…"
                            $ interaction_reward = get_interaction_reward(roxy_afeicao)
                            $ roxy_afeicao += interaction_reward
                            $ roxy_interacted_today = True
                            $ renpy.notify("Твоя привязанность к Рокси повысилась на +{}!".format(interaction_reward))
                            jump passar_tempo
                    "Заняться с ней анальным сексом (80)":

                        if roxy_afeicao < 80:
                            "Чтобы открыть этот вариант, нужно не менее 80 очков привязанности."
                            jump roxy_interact_menu
                        else:

                            rudeus "Эй, учитель… повернись и наклонись."
                            roxy "Ч-что ты задумал на этот раз, Рудеус?"
                            rudeus "Может, позволишь мне приласкать тебя языком?"
                            roxy "П-приласкать меня языком? Рудеус, это же так непристойно…"
                            rudeus "Ну же… обещаю, тебе понравится."
                            roxy "М-м… Ладно…"
                            scene vid_roxy_anilingus with fade
                            roxy "А-а-а… Р-Рудеус…"
                            roxy "Твой язык… такой приятный…"
                            rudeus "Хе-хе… Тебе ведь нравится, когда я так ласкаю тебя, учитель?"
                            roxy "М-м… Д-да… У тебя это слишком хорошо получается…"
                            rudeus "Подожди, пока почувствуешь меня внутри…"
                            roxy "А-а… Ну и распутник…"
                            $ interaction_reward = get_interaction_reward(roxy_afeicao)
                            $ roxy_afeicao += interaction_reward
                            $ roxy_interacted_today = True
                            $ renpy.notify("Твоя привязанность к Рокси повысилась на +{}!".format(interaction_reward))
                            jump passar_tempo
                    "Предложить анальный секс (180)":

                        if roxy_afeicao < 180:
                            "You need at least 180 affection to unlock this option."
                            jump roxy_interact_menu
                        else:


                            rudeus "Рокси… Я хочу войти в тебя до конца…"
                            roxy "Д-до конца? Н-но… я никогда раньше не пробовала такое…"
                            rudeus "Не волнуйся, я буду осторожен… поначалу."
                            scene vid_roxy_anal with fade
                            roxy "Ах… П-помедленнее, извращенец…"
                            roxy "Ты так сильно меня растягиваешь…"
                            rudeus "Я-я ничего не могу с собой поделать, учитель…"
                            rudeus "Ты такая узкая…"
                            roxy "М-м… Тебе настолько нравится моя попка?"
                            rudeus "Да… Мне нравится, как ты сжимаешься вокруг меня…"
                            roxy "М-м… Это так странно ощущается…"
                            roxy "У меня даже ощущение, будто хочется в туалет…"
                            rudeus "Потерпи ещё немного, учитель…"
                            rudeus "Я-я сейчас кончу…"
                            call gozando from _call_gozando_9
                            play sound "cum.mp3"
                            scene roxy_anal_cum with fade
                            roxy "А-а… Ты… ты кончил в меня…"
                            rudeus "Ах… Учитель, ты лучшая…"
                            rudeus "Такими темпами я стану сильнейшим магом на всём континенте…"
                            $ interaction_reward = get_interaction_reward(roxy_afeicao)
                            $ roxy_afeicao += interaction_reward
                            $ roxy_interacted_today = True
                            $ renpy.notify("Твоя привязанность к Рокси повысилась на +{}!".format(interaction_reward))
                            jump passar_tempo
                    "Назад":


                        jump roxy_menu
        "Вернуться":

            jump locais
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
